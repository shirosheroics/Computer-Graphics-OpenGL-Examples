//Shorook Mohamed Saleh
//Submitted 

#ifdef WIN32
#include <windows.h>
#endif

#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <cmath>


#ifdef __APPLE__
#include <GLUT/glut.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>
#endif
#include "vector.h"
#define M_PI 3.141592653589793238462643


using namespace std;

const int screenWidth = 800;
const int screenHeight = 600;

int clicks = 0, position=0, Poly1, Poly2;
Vector Pv1[100], Pv2[100],Pvp1[100], Pvp2[100] ;
Point P1[100], P2[100], S, mouseTrack, diff;
bool  isSelected = false, done1 = false, done2= false, rot = false;
float ang = 0;
int mx , my;
//<<<<<<<<<<<<<<<<<<<<<<< myInit >>>>>>>>>>>>>>>>>>>>

void setWindow(GLdouble left, GLdouble right, GLdouble bottom, GLdouble top)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(left, right, bottom, top);
    
}

void setViewport(GLint left, GLint right, GLint bottom, GLint top)
{
    glViewport(left, bottom, right - left, top - bottom);
}

void myInit(void)
{
    glClearColor(1.0, 1.0, 1.0, 0.0);       // set white background color
    glColor3f(0.0f, 0.0f, 0.0f);          // set the drawing color
    glPointSize(8.0);       // a ëdotí is 4 by 4 pixels
    glEnable(GL_POINT_SMOOTH);
    
}

//<<<<<<<<<<<<<<<<<<<<<<<< myDisplay >>>>>>>>>>>>>>>>>

void myDisplay(void)
{
    
    glClear(GL_COLOR_BUFFER_BIT);     // clear the screen
    setWindow(0, screenWidth, 0, screenHeight);
    setViewport(0 ,screenWidth , 0, screenHeight);
    
    // After right click, draw the first Polygon segments
    if (done1)
    {
        // Draw the polygon
        glColor3f(0.0, 1.0, 0.0);
        
        glBegin(GL_LINE_LOOP);
        for(int i =0; i < Poly1; i++ )
        glVertex2d(P1[i].x, P1[i].y);
        glEnd();
        
        // Calculate the vectors & Calculate the perpendaculars
        for(int i =0; i < Poly1; i++)
        {
            Pv1[i] = P1[(1+i)%Poly1] - P1[i];
            Pvp1[i] = perp(Pv1[i]);
        }
        
    }
    // Draw the end points of the first polygone segments
    for (int i = 0; i < Poly1; i++)
    {
        glColor3f(0.0, 0.0, 1.0);
        glBegin(GL_POINTS);
        glVertex2d(P1[i].x, P1[i].y);
        glEnd();
    }
    
    //SECOND
    // After right click, draw the second Polygon segments
    if (done2)
    {
        
        // Draw the polygon
        glColor3f(0.0, 0.0, 1.0);
        
        glBegin(GL_LINE_LOOP);
        for(int i =0; i < Poly2; i++ )
            glVertex2d(P2[i].x, P2[i].y);
        glEnd();
        
        // Calculate the vectors & Calculate the perpendaculars
        for(int i =0; i < Poly1; i++)
        {
            Pv2[i] = P2[(1+i)%Poly2] - P2[i];
            Pvp2[i] = perp(Pv2[i]);
        }
        
    }
    // Draw the end points of the second polygone segments
    if (done1)
    for (int i = 0; i < Poly2; i++)
    {
        glColor3f(0.0, 1.0, 0.0);
        glBegin(GL_POINTS);
        glVertex2d(P2[i].x, P2[i].y);
        glEnd();
    }
    
    
    //Find intersection
    if(done1 && done2)
    {
        for(int i = 0; i < Poly1 ; i++ ){
            for (int j =0; j < Poly2; j++)
            {
                if (((Pv1[i].x * Pvp2[j].x) + (Pv1[i].y * Pvp2[j].y) + (Pv1[i].z * Pvp2[j].z))!= 0 ||
                    ((Pvp1[i].x * Pv2[j].x) + (Pvp1[i].y * Pv2[j].y) + (Pvp1[i].z * Pv2[j].z))!= 0) {
                
                    Vector c = P2[j] - P1[i];
                    
                    double t = (c.x*Pvp2[j].x+c.y*Pvp2[j].y+c.z*Pvp2[j].z)/
                    ( Pvp2[j].x*Pv1[i].x+ Pvp2[j].y*Pv1[i].y+ Pvp2[j].z*Pv1[i].z);
                    
                    double u = - (c.x*Pvp1[i].x+c.y*Pvp1[i].y+c.z*Pvp1[i].z)/
                    ( Pv2[j].x*Pvp1[i].x+ Pv2[j].y*Pvp1[i].y+ Pv2[j].z*Pvp1[i].z);
                    
                    S = P1[i] + Pv1[i]*(t);
                    
                    if ( (t >=0 && t <=1 ) && ( u >=0 && u <=1)){
                    glColor3f(1.0, 0.0, 0.0);
                    glBegin(GL_POINTS);
                    glVertex2d(S.x, S.y);
                    glEnd();
                    }
                }
            }
        }
    }
    
    
    glFlush();                 // send all output to display
    glutSwapBuffers();
    
}


double Distance(const Point& p1, const Point& p2)
{
    Vector v = p2 - p1;
    return v.norm();
}

void myMouse(int button, int state, int x, int y)
{
    mx = x; my = screenHeight - y;
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)//land points
    {
        if (!done1){
            P1[clicks] = Point(x, screenHeight - y);
            clicks++;
        }
        else if ( !done2)
        {
            P2[clicks] = Point(x, screenHeight - y);
            clicks++;
        }
        if (!done1)
        Poly1 = clicks;
        else if ( ! done2)
        Poly2 = clicks;

    }
    
    if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)//confirm polys
    {
        if (clicks >1 )
            if(!done1) {
                done1 = true;
                Poly1 = clicks;
                clicks =0;

                }
            else
                if(done1)
                {
                    done2 =true;
                    Poly2 = clicks;
                    clicks =0;
                }
       
    }

    if (button == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) //clear
    {
        clicks = 0;
        Poly1 =0;
        Poly2=0;
        done1 =0;
        done2 =0;
    }
    
    glutPostRedisplay();
}


void mouseMotion(int x, int y)
{
    // Update the location of the current point as the mouse moves with button pressed.
    mx = x; my = screenHeight - y;
    mouseTrack.x = mx;
    mouseTrack.y = my;
    
    //Moving first polygon
    for (int i =0; i <Poly1; i++)
    if (Distance(mouseTrack, P1[i]) <= 8 && rot != true) {
        
        diff.x = P1[i].x - mouseTrack.x;
        diff.y = P1[i].y - mouseTrack.y;
        position = i;
        for(int i =0; i < Poly1; i++)
        {
            P1[i].x -= diff.x;
            P1[i].y -= diff.y;
        }
    }
    
    //Moving second polygon
    for (int i =0; i <Poly2; i++)
        if (Distance(mouseTrack, P2[i]) <= 8) {
         
            diff.x = P2[i].x - mouseTrack.x;
            diff.y = P2[i].y - mouseTrack.y;
            position = i;
            for(int i =0; i < Poly2; i++)
            {
                P2[i].x -= diff.x;
                P2[i].y -= diff.y;
            }
        }
    
    
    
    glutPostRedisplay();
}

//<<<<<<<<<<<<<<<<<<<<<<<< main >>>>>>>>>>>>>>>>>>>>>>

int main(int argc, char** argv)
{
    
    glutInit(&argc, argv);          // initialize the toolkit
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB); // set display mode
    glutInitWindowSize(screenWidth, screenHeight);     // set window size
    glutInitWindowPosition(100, 100); // set window position on screen
    glutCreateWindow("Intersection between two Poygons"); // open the screen window
    glutDisplayFunc(myDisplay);     // register redraw function
    glutMouseFunc(myMouse);
    glutMotionFunc(mouseMotion);
    
    
    
    myInit();
    
    glutMainLoop();      // go into a perpetual loop
    
}

